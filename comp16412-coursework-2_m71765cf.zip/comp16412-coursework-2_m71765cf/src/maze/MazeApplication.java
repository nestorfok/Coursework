package maze;

import javafx.application.Application;

public class MazeApplication extends Application {

}
