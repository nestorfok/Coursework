package maze;

public class MazeDriver {
    public static void main(String args[]) {
        Maze maze = Maze.fromTxt("../mazes/maze1.txt");
    }
}
