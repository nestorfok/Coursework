package maze;

import java.util.*;
import java.io.*;
import java.io.FileNotFoundException;

public class Maze implements Serializable{
    private Tile entrance;
    private Tile exit;
    private List<List<Tile>> tiles;

    public enum Direction {
        NORTH,
        EAST,
        SOUTH,
        WEST
    }

    private Maze() {
        entrance = null;
        exit = null;
        tiles = new ArrayList<List<Tile>>();
    }

    // Covert the file to a 2-D list of tiles.
    public static Maze fromTxt(String a) throws FileNotFoundException, IOException{
        Maze originMaze = new Maze();
        int charLength = 0;
        Tile entrance;
        Tile exit;
        Tile scanTile;
        FileReader file = new FileReader(a);
        BufferedReader bf = new BufferedReader(file);
        String line = bf.readLine();
        line = bf.readLine();
        List<List<Tile>> tiles = originMaze.getTiles();
        while (line != null) {
            char[] info = line.toCharArray();
            List<Tile> tile = new ArrayList<Tile>();
            if (charLength == 0) {
                charLength = info.length;
            } else if (charLength != info.length) {
                System.out.println("Structure of maze is incorrect");
            }

            List<Tile> tileEachLine = new ArrayList<>();

            for (int i=0; i<info.length; i++) {
                scanTile = Tile.fromChar(info[i]);
                tileEachLine.add(scanTile);
                if (info[i] == 'e') {
                    entrance = scanTile;
                    System.out.println("entrance");
                }
                else if (info[i] == 'x') {
                    exit = scanTile;
                    System.out.println("exit");
                }
            }
            tiles.add(tileEachLine);
        }
        file.close();
        bf.close();
        return originMaze;
    }

    public Tile getExit() {
        return exit;
    }

    public Tile getEntrance() {
        return entrance;
    }

    public List<List<Tile>> getTiles() {
        return tiles;
    }

    public void setExit(Tile exit) {
        this.exit = exit;
    }

    public void setEntrance(Tile entrance) {
        this.entrance = entrance;
    }

    public String toString() {
        String mazeInString;
        for (int i=0; i<tiles.size(); i++) {
            mazeInString = "";
        }
    }



}
