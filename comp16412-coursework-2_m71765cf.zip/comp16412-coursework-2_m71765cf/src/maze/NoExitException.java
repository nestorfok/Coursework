package maze;

public class NoExitException extends InvalidMazeException{

    public NoExitException() {
        super("There is no exit in the maze");
    }

    public NoExitException(String error) {
        super(error);
    }
}
