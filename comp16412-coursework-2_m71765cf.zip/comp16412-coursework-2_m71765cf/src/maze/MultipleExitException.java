package maze;

public class MultipleExitException extends InvalidMazeException{

    public MultipleExitException(){
        super("There should not be multiple exits");
    }

    public MultipleExitException(String error) {
        super(error);
    }
}
