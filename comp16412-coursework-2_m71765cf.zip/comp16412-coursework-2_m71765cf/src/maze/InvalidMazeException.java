package maze;

public class InvalidMazeException extends RuntimeException{

    public InvalidMazeException() {
        super ("Invalid Maze");
    }

    public InvalidMazeException(String error) {
        super(error);
    }
}
