package maze;

public class RaggedMazeException {
}
