package maze;

public class NoEntranceException {
}
