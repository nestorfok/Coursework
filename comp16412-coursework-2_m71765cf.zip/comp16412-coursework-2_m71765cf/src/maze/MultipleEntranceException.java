package maze;

public class MultipleEntranceException {
}
