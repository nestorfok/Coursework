package maze;
import java.lang.*;

public class Tile implements java.io.Serializable{

    private Type type;

    public enum Type{
        CORRIDOR,
        ENTRANCE,
        EXIT,
        WALL
    }

    public Tile(Type tileType) {
        type = tileType;
    }

    // Return the type depends on the character
    protected static Tile fromChar(char character) throws InvalidMazeException {
        Type charType;
        if (character == '.') {
            charType = Type.CORRIDOR;
        }
        else if (character == 'e') {
            charType = Type.ENTRANCE;
        }
        else if (character == 'x') {
            charType = Type.EXIT;
        }
        else if (character == '#') {
            charType = Type.WALL;
        }
        else {
            throw new InvalidMazeException();
        }
        return new Tile(charType);
    }

    public Type getType() {
        return type;
    }

    // Check if it is in the route
    public boolean isNavigable() {
        if (this.type == Type.CORRIDOR || this.type == Type.ENTRANCE || this.type == Type.EXIT) {
            return true;
        }
        else return false;
    }

    // Return the visual character according to the type
    public String toString() {
        if (this.type == Type.CORRIDOR) {
            return ".";
        }
        else if (this.type == Type.ENTRANCE) {
            return "e";
        }
        else if (this.type == Type.EXIT) {
            return "x";
        }
        else if (this.type == Type.WALL) {
            return "#";
        }
        else return " ";
    }
}
